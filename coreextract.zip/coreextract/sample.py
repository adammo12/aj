import urllib2
import extract

def main():
	import os, os.path, urllib2
	
	# Proxy for web access from kyoto-u
	PROXY = urllib2.ProxyHandler({
		"http": "http://proxy.kuins.net:8080/",
		"https": "http://proxy.kuins.net:8080/"})
	
	urllib2.install_opener(urllib2.build_opener(PROXY))
	
	url = "http://hollywoodcrush.mtv.com/2011/11/14/hunger-games-trailer-expert-reactions/"
	
	f = urllib2.urlopen(url)
	html = f.read()
	f.close()
	
	# ignore some encode errors ... but sometimes happend in BeautifulSoup
	html = unicode(html, "utf_8", "ignore")
	text = extract.coretext(html)
	print text

if __name__=="__main__": main()
