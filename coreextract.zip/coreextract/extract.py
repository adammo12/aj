import codecs
import re
import math
from htmlentitydefs import name2codepoint
from BeautifulSoup import *

def average(iterable, key=lambda x:x):
	N = float(len(iterable))
	if N == 0.0: return 0.0
	return math.fsum([key(x) for x in iterable]) / N

def unbiased_variance(iterable, key=lambda x:x):
	N = float(len(iterable))
	if N < 2.0: return 0.0
	avg = average(iterable, key)
	var2 = math.fsum([(key(v)-avg)**2 for v in iterable]) / (N - 1)
	return math.sqrt(var2)


# http://www.mne.psu.edu/me345/lectures/Outliers.pdf
TAU = [
	( 3, 1.1511), ( 4, 1.4250), ( 5, 1.5712), ( 6, 1.6563),
	( 7, 1.7110), ( 8, 1.7491), ( 9, 1.7770), (10, 1.7984),
	(11, 1.8153), (12, 1.8290), (13, 1.8403), (14, 1.8498),
	(15, 1.8579), (16, 1.8649), (17, 1.8710), (18, 1.8764),
	(19, 1.8811), (20, 1.8853), (21, 1.8891), (22, 1.8926),
	(23, 1.8957), (24, 1.8985), (25, 1.9011), (26, 1.9035),
	(27, 1.9057), (28, 1.9078), (29, 1.9096), (30, 1.9114),
	(31, 1.9130), (32, 1.9146), (33, 1.9160), (34, 1.9174),
	(35, 1.9186), (36, 1.9198), (37, 1.9209), (38, 1.9220),
	(40, 1.9240), (42, 1.9257), (44, 1.9273), (46, 1.9288),
	(48, 1.9301), (50, 1.9314), (55, 1.9340), (60, 1.9362),
	(65, 1.9381), (70, 1.9397), (80, 1.9423), (90, 1.9443),
	(100, 1.9459), (200, 1.9530), (500, 1.9572),
	(1000, 1.9586), (5000, 1.9597), (float("+inf"), 1.9600) ]

def tau(n):
	global TAU
	for i in xrange(len(TAU)-1):
		v1, t1 = TAU[i]
		v2, t2 = TAU[i+1]
		if v1 <= n < v2: return t1
	return TAU[-1][1]


IGNORETYPE = (Comment, Declaration)
IGNORETAG = ["script", "style", "link", "meta", "img", "noscript"]
REPLACETAG = ["a", "b", "big", "center", "cite", "em", "font", "i", "q", "small", "span", "strong", "sub", "u"]
REPLACEWITHDOT = ["p"]

def cleanup(soup):
	global IGNORETYPE, IGNORETAG, REPLACETAG, REPLACEWITHDOT
	
	soup = BeautifulSoup(str(soup))
	f = lambda text: isinstance(text, IGNORETYPE) or ("<![CDATA[" in text)
	for t in soup.findAll(text=f): t.extract()
	
	soup = BeautifulSoup(str(soup))
	for t in soup.findAll(IGNORETAG): t.extract()
	
	soup = BeautifulSoup(str(soup))
	for t in soup.findAll(REPLACETAG): t.replaceWithChildren()
	
	soup = BeautifulSoup(str(soup))
	for t in soup.findAll(REPLACEWITHDOT):
		text = t.getText() + ".\n"
		t.replaceWith(NavigableString(text))
	
	html = str(soup).replace("\r"," ").replace("\n"," ")
	soup = BeautifulSoup(html)
	return soup

RXMULTIDOT = re.compile(r"(\.\n?){2,}")
RXMULTISPACE = re.compile(r"(\s){2,}")
RXUNNECESSARY = re.compile(r"(^|[!?;:,\.])\.")
RXENTITYREF = re.compile(r"&(\w+?);")
RXUNKNOWN = re.compile(r"([A-Za-z]\.)([A-Za-z])")
def getAllText(soup):
	global RXMULTIDOT, RXMULTISPACE, RXUNNECESSARY, RXENTITYREF
	text = soup.getText(".\n")
	text = RXMULTIDOT.sub(r"\1", text)
	text = RXMULTISPACE.sub(r"\1", text)
	text = RXUNNECESSARY.sub(r"\1", text)
	text = RXUNKNOWN.sub(r"\1 \2", text)
	conv = lambda m: unichr(name2codepoint.get(m.group(1),0x20))
	text = RXENTITYREF.sub(conv, text)
	return text

def max_thompson_tau(iterable, key=lambda x:x, delf=lambda x:x, alpha=4.0):
	y = list(iterable)
	L = True
	while L:
		L = False
		N = len(y)
		if N < 3: break
		t = tau(N)
		u = key(max(y, key=key))
		S = unbiased_variance(y, key)
		dels = []
		for yi in y:
			d = math.fabs(key(yi) - u)
			if d < (alpha * t * S): continue
			dels += [yi]
		
		L = len(dels) > 0
		for yi in dels:
			delf(yi)
			y.remove(yi)
	return y

def getCoreText(soup, alpha=4.0):
	lens = [(len(i), i) for i in soup.findAll(text=True)]
	lens = max_thompson_tau(lens, key=lambda x:x[0], 
		delf=lambda x:x[1].extract(), alpha=alpha)
	
	for item in soup.findAll(text=True):
		if len(item) <= 5: item.extract()
	
	return getAllText(soup)

def plaintext(html):
	soup = BeautifulSoup(html)
	soup = cleanup(soup)
	text = getAllText(soup)
	return text

def coretext(html):
	soup = BeautifulSoup(html)
	soup = cleanup(soup)
	text = getCoreText(soup)
	return text

if __name__=="__main__":
	import os, os.path, urllib2
	PROXY = urllib2.ProxyHandler({
		"http": "http://proxy.kuins.net:8080/",
		"https": "http://proxy.kuins.net:8080/"})
	
	urllib2.install_opener(urllib2.build_opener(PROXY))
	
	url = "http://hollywoodcrush.mtv.com/2011/11/14/hunger-games-trailer-expert-reactions/"
	
	f = urllib2.urlopen(url)
	html = f.read()
	f.close()
	
	html = unicode(html, "utf_8", "ignore")
	text = coretext(html)
	print text

